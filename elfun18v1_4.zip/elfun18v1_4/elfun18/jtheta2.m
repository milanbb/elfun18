function result = jtheta2( x, q)
%JTHETA1 Calculate Jacobi theta2(x,q)

    result = jtheta0( 2, x, q);
    
end


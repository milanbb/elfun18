function result = gcl(x)
%GCL Gauss lemniscate cos.
%
%   Functions called:
%       slcl

    [~, result] = gslcl( x);

end


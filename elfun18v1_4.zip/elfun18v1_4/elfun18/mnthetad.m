function result = mnthetad( u, m)
%MNTHC Neville theta function D

result = nthetad( u, melnome(m));

end
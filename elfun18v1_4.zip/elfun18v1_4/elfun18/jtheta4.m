function result = jtheta4( x, q)
%JTHETA1 Calculate Jacobi theta4(x,q)

    result = jtheta0( 4, x, q);
    
end


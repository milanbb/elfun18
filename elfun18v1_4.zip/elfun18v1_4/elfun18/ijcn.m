function result = ijcn( x, k)
%IJCN Inverse of Jacobi elliptic function CN
%
%   Functions called:
%       mijcd

    result = mijcn( x, k^2);
    
end

function result  = ijsc( x, k)
%IJSC Return the inverse of Jacobi elliptic function SC
%

    result = mijsc( x, k^2);
    
end

function result = ijsd( x, k)
%IJSD Return the inverse of Jacobi elliptic function SD
%

    result = mijsd( x, k^2);
        
end


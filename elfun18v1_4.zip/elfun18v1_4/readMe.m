%elfun18v1_4
%
% (1) Correction of functions JacobiTheta and jtheta
% (2) Function JacobiK, jK are added. These functions returns value of real
% part of the complete elliptic integral of the 1st kind for any real k. 
% Note that EllipticK and elK returns value only for |k| < 1
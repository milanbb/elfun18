%testJacobiK
k=linspace(-2,2);
f = JacobiK(k);
f1 = EllipticK(k);
figure
hold on
plot(k,f)
plot(k,f1,'LineWidth',2)
grid on
title('JacobiK')